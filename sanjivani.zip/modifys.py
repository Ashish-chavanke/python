# Accept a string from the user
input_string = input("Enter a string: ")

# Initialize an empty string for the result
modified_string = ""

# Iterate through each character in the input string
for char in input_string:
    if char.lower() in "aeiou":  # Check if the character is a vowel (case insensitive)
        modified_string += "*"  # Replace vowel with '*'
    else:
        modified_string += char  # Keep the non-vowel character as it is

# Print the modified string
print("Modified string:", modified_string)
