# Define a list of integers
numbers = [45, 23, 89, 12, 67, 34, 90]

# Sort the list in descending order
numbers.sort(reverse=True)

# Print the sorted list
print("Sorted list in descending order:", numbers)
