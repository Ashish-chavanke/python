class A: 
    x = "Hello" 
    y = "World"   # Now y is inside class A

class B(A): 
    pass 

# Create object of class B 
obj = B()

# Print inherited attributes 
print("Attribute 1:", obj.x)
print("Attribute 2:", obj.y)