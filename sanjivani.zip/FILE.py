# Write to a file 
with open("sample.txt", "w") as f:  
    f.write("This is a sample text.") 
 
# Read from file  
with open("sample.txt", "r") as f:  
    content = f.read() 
    print("File content:", content)
