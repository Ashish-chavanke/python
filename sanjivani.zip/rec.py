class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def perimeter(self):
        return 2 * (self.length + self.width)

# Example usage
rect = Rectangle(5, 3)
print("Rectangle Area:", rect.area())
print("Rectangle Perimeter:", rect.perimeter())

import math

class Circle:
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

# Accept radius input from user
r = float(input("Enter the radius of the circle: "))
circle = Circle(r)
print("Circle Area:", circle.area())

class Book:
    def __init__(self, title, author, price):
        self.title = title
        self.author = author
        self.price = price

    def display(self):
        print("Title:", self.title)
        print("Author:", self.author)
        print("Price: ₹", self.price)

# Example usage
book1 = Book("Atomic Habits", "James Clear", 450)
book1.display()
