import math 
num = float(input("Enter a number: ")) 
sqrt = math.sqrt(num) 
print("Square root of", num, "is", sqrt) 