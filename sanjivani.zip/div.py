# Input the number from the user
num = int(input("Enter a number: "))

# Check if the number is divisible by both 2 and 4
if num % 2 == 0 and num % 4 == 0:
    print(f"{num} is divisible by both 2 and 4.")
else:
    print(f"{num} is not divisible by both 2 and 4.")