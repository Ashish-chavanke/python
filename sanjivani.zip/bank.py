class BankAccount:
    def __init__(self, account_holder, balance):
        self.account_holder = account_holder
        self.balance = balance

    def display_account(self):
        print("Account Holder:", self.account_holder)
        print("Balance: ₹", self.balance)

# Example usage
account1 = BankAccount("Ashish Chavankke", 5000)
account1.display_account()
 