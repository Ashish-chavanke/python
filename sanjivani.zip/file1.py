# Open a new text file in write mode
with open("name.txt", "w") as file:
    # Write your name into the file
    file.write("Ashish Chavankke")

# Notify that the name has been written
print("Your name has been written to 'name.txt'.")


# Open the file in read mode
with open("example.txt", "r") as file:
    # Read all lines and count them
    lines = file.readlines()
    line_count = len(lines)

# Print the number of lines in the file
print("Number of lines in the file:", line_count)

# Open the file in read mode
with open("example.txt", "r") as file:
    # Read the content of the file
    content = file.read()

# Split the content into words and count them
words = content.split()
word_count = len(words)

# Print the total number of words in the file
print("Total number of words in the file:", word_count)

# Define the file path
file_path = "example.txt"

# Open the file in write mode (this will overwrite the file)
with open(file_path, "w") as file:
    # Write new content to the file
    file.write("This is the new content that will overwrite the old content.")

print(f"The file '{file_path}' has been overwritten with new content.")
