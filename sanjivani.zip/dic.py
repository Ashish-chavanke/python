student = { 
    "Riya": "A+", 
    "Aman": "B", 
    "Neha": "C" 
} 
 
# Add a new student 
student["Rahul"] = "B+" 
 
# Update a grade 
student["Aman"] = "A" 
 
# Delete a student 
del student["Neha"] 
# Print all student records 
print("Student Records:") 
for name in student: 
print(name, ":", student[name]) 