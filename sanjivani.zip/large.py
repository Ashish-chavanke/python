# Define a list of numbers
numbers = [45, 78, 12, 98, 23, 56, 11, 89]

# Find the largest and smallest number using built-in functions
largest = max(numbers)
smallest = min(numbers)

# Print the results
print("Largest number:", largest)
print("Smallest number:", smallest)
