# Define two sets
set1 = {1, 2, 3, 4, 5}
set2 = {4, 5, 6, 7, 8}

# Find the intersection using the & operator
intersection = set1 & set2
print("Intersection using '&' operator:", intersection)

# Find the intersection using the .intersection() method
intersection_method = set1.intersection(set2)
print("Intersection using '.intersection()' method:", intersection_method)
