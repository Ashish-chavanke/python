# Create a dictionary with 5 elements where the value is the squared value of the key
squared_dict = {x: x**2 for x in range(1, 6)}

# Print the dictionary
print(squared_dict)
