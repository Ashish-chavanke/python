class Car: 
  brand = "" 
model = "" 
car1 = Car() 
car1.brand = "Hyundai" 
car1.model = "i20" 
print("Brand:", car1.brand) 
print("Model:", car1.model)