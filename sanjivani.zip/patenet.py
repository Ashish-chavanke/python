class Patient:
    def __init__(self, name, disease):
        self.__name = name         # Private attribute
        self.__disease = disease   # Private attribute

    # Getter methods
    def get_name(self):
        return self.__name

    def get_disease(self):
        return self.__disease

    # Setter methods
    def set_name(self, name):
        self.__name = name

    def set_disease(self, disease):
        self.__disease = disease

# Example usage
p1 = Patient("Riya", "Flu")
print("Patient Name:", p1.get_name())
print("Disease:", p1.get_disease())

# Update data securely
p1.set_disease("Cold")
print("Updated Disease:", p1.get_disease())
