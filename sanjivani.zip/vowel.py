# Input string
text = input("Enter a string: ")

# Vowel list
vowels = "aeiouAEIOU"

# Counter variable
count = 0

# Loop to count vowels
for char in text:
    if char in vowels:
        count += 1

# Print the result
print("Number of vowels:", count)
 