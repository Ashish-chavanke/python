total_sum = 0

for i in range(1, 101):  # Loop from 1 to 100
    total_sum += i       # Add each number to total_sum

print("The sum of the first 100 natural numbers is:", total_sum)
