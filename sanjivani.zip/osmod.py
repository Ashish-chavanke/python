import os

# Define the file path
file_path = "example.txt"

# Check if the file exists
if os.path.exists(file_path):
    # Open the file in read mode to read its contents
    with open(file_path, "r") as file:
        content = file.read()
    print("File content:")
    print(content)
else:
    print(f"The file '{file_path}' does not exist.")

# Optionally, overwriting the file with new content
new_content = "This is new content that will overwrite the file."
# Check if the file exists before overwriting it
if os.path.exists(file_path):
    # Open the file in write mode (this will overwrite the file)
    with open(file_path, "w") as file:
        file.write(new_content)
    print(f"The file '{file_path}' has been overwritten with new content.")
else:
    print(f"File '{file_path}' does not exist, so no overwriting was done.")
