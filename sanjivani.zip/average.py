total = 0

# Loop to get 5 numbers from user
for i in range(5):
    num = float(input(f"Enter number {i+1}: "))
    total += num

# Calculate average
average = total / 5

# Print the result
print("The average of the 5 numbers is:", average)