# Base class
class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        print(f"{self.name} makes a sound.")

# Subclass
class Dog(Animal):
    def bark(self):
        print(f"{self.name} says: Woof! Woof!")

# Create an object of Dog class
dog1 = Dog("Bruno")

# Call methods
dog1.speak()  # Inherited method from Animal
dog1.bark()   # Method from Dog class
 