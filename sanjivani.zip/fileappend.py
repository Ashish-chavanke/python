# Append to file 
 with open("sample.txt", "a") as f: 
    f.write("\nAppended text.") 
  
# Read to verify 
 with open("sample.txt", "r") as f: 
    print(f.read())