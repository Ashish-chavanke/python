# Define a list of numbers
numbers = [10, 15, 22, 33, 40, 51, 60, 71, 82]

# Initialize a variable to store the sum of even numbers
sum_even = 0

# Iterate through the list and add even numbers to the sum
for num in numbers:
    if num % 2 == 0:
        sum_even += num

# Print the sum of even numbers
print("Sum of all even numbers:", sum_even)
