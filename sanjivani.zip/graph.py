Draw a line in a diagram from position (x1, y1) to (x2, y2) 
Answer (Code): 
 import matplotlib.pyplot as plt

x1, y1 = 1, 2
x2, y2 = 4, 6

plt.plot([x1, x2], [y1, y2], marker='o')
plt.title("Line from (x1, y1) to (x2, y2)")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.grid(True)
plt.show()
