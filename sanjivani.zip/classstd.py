class Student:
    def __init__(self, name, score):
        self.name = name
        self.score = score

    def display(self):
        print("Name:", self.name)
        print("Score:", self.score)
s1 = Student("Alice", 92)
s1.display()
 