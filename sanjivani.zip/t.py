# Input the string from the user
string = input("Enter a string: ")

# Check if 't' is in the string
if 't' in string:
    print("The string contains the character 't'.")
else:
    print("The string does not contain the character 't'.")