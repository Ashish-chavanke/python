# Define a list of words
words = ["apple", "banana", "orange", "grape", "elephant", "kiwi"]

# List of vowels
vowels = "aeiou"

# Iterate through the list and check if the word starts with a vowel
for word in words:
    if word[0].lower() in vowels:
        print(word)
