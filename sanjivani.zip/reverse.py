text = "THISISWORLDBESTPRATICE" 
reversed_text = text[::-1] 
print(reversed_text) 